import React from 'react';

function CardDetailPage(props){
    const {showSelected}=props;

    const removeTags=(stringReplace)=>{
      return stringReplace!==null? stringReplace.replace(/(<([^>]+)>)/gi, ""):'';
    }

    return(
      <a  className=" card dflex w-100" href={showSelected.show.url}>
              <div className="dflex">
                {showSelected.show.image?<img src={showSelected.show.image.medium} alt={showSelected.show.name}/>:''}
                <div className="text-section">
                  <div className="show-heading">{showSelected.show.name}</div>
                  <div><span>Rating :</span>{showSelected.show.rating.average}</div>
                  <div><span>Genres : </span>{showSelected.show.genres}</div>
                  <div>{showSelected.show.language}</div>
                  <div><span>Runtime : </span>{showSelected.show.averageRuntime}</div>
                  <div>{removeTags(showSelected.show.summary)}</div>
                
                </div>
              </div>
            </a>

    );
  
}

export default CardDetailPage;