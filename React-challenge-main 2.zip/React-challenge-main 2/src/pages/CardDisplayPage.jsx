import React from 'react';
import {useNavigate} from 'react-router-dom';
import SearchBox from '../components/SearchBox';

function CardDisplayPage(props){
  const navigate= useNavigate();

  const cardClick=(show)=>{
    props.openCard(show);
    navigate('/detail/'+show.show.id);
  }

    return(
      <div className="flexwrapcontainer">
          <SearchBox searchUpdate={props.searchUpdate} ></SearchBox> 
         {props.showDetails && props.showDetails.length>0?
        props.showDetails.map((show,index)=>{
          return(
            <div key={index} className=" card dflex" onClick={()=>cardClick(show)}>
              <div className="dflex">
                {show.show.image?<img src={show.show.image.medium} alt={show.show.name}/>:
                <img src="../assets/noimage.jpeg" alt={show.show.name} className="noimage"/>}
                <div className="text-section">
                  <p className="show-heading">{show.show.name}</p>
                  <p>{show.show.rating.average}</p>
                </div>
              </div>
            </div>
          )
        }):<p>Sorry! We dont have any shows to display</p>
        }</div>

    );
  
}

export default CardDisplayPage;