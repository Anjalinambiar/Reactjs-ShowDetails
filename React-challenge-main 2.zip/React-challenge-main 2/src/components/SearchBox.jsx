import React, { useState } from "react";

export const SearchBox = (props) => {
    const [searchValue,setSearchValue]=useState('');

    const searchhandleChange=(event)=>{
      setSearchValue(event.target.value);
      props.searchUpdate(event.target.value);
    }

  return (
        <input className="searchbox" onChange={(event)=>searchhandleChange(event)} value={searchValue}
        placeholder="Search in Shows.."/>
   
  );
};

export default SearchBox;