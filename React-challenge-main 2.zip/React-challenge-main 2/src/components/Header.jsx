import React from "react";
import { Link } from "react-router-dom";
import logo from "../assets/fxdigitallogo.png";
import SearchBox from "./SearchBox";

export const Header = (props) => {
  return (
    <header>
      <nav>
        <img src={logo} alt="logo" />  
        <div>
          <Link to="/">Home</Link>
        </div>
      </nav>
    </header>
  );
};

export default Header;