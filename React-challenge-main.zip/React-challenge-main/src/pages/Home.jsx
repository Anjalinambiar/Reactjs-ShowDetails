import React, { useState,useEffect }from 'react';
import axios from 'axios';
import { Route,Routes} from 'react-router-dom';
import CardDisplayPage from './CardDisplayPage';
import CardDetailPage from './CardDetailPage';


export const Home = () => {

  const [responseData,getresponseData]=useState([]);
   const [filteredData,setfilteredData]=useState([]);
  const [showSelected,setShowselected]=useState([]);
 

  const fetchData=()=>{
    axios.get('https://api.tvmaze.com/search/shows?q=girls').then((response)=>{
      getresponseData(response.data);
      setfilteredData(response.data);
    })
    .catch((error)=>{
      //catch error
    })
  }

  const searchUpdate=(searchvalue)=>{
    let resultData= searchvalue!==''?responseData.filter(item=>item.show.name.toLowerCase().indexOf(searchvalue.toLowerCase())>-1):responseData;
    setfilteredData(resultData);
    
  }

  const openCard=(show)=>{
    setShowselected(show);
  }

  useEffect(()=>{
    fetchData();
  },[])

  return (
      <Routes>
            <Route path='/' element={<CardDisplayPage showDetails={filteredData} openCard={openCard} 
                searchUpdate={searchUpdate}/>} />
            <Route path='/detail/:id' element={<CardDetailPage showSelected={showSelected}/>} />
       </Routes>
  );
};

export default Home;